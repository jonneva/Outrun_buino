#ifndef GAME_H
#define GAME_H

#include "wrapper.h"

// GRAPHICS SETUP CONSTANTS

#define TVX         104     // 112x56 = 6272 bytes 104x56 = 5824
#define TVY         56      // 136x96 = 13056 bytes
#define TVXCENTER   TVX/2   // 120x64 = 7680 bytes
#define TVYCENTER   TVY/2
#define HORIZON     16 //TVYCENTER+5

// GAME SETUP CONSTANTS

#define ZLINES      20  // number of rumble segments
#define ZSTEP       25  // length of rumble segments
#define DXDIV       32  // Number of steps from centerline to roadside
#define NUMSPOTS    5   // Number of roadside spots flying by
#define ACCELTIME   60  // Time that wheels are "smoking"
#define CARY        TVY-25

#define ROADW       1000    // Road width in worldspace
#define Y_CAMERA    1140    // Camera height for lookup table calculation
#define Z_MULT      4       // Z multiplier
#define YTABS       TVY-HORIZON+1   // lookup table sizes = how many y lines are checked
#define RUMBLEW     8       // Rumble width, higher number = thinner
#define RUMBLEOFFS  16      // define rumble offset from road side, higher = less

// GAME LOOKUP TABLES

extern int zlookup[],x1lookup[],x2lookup[],xlookup[],dxlookup[];
extern byte colorlookup[];
extern int xspots[NUMSPOTS];
extern int zspots[NUMSPOTS];
extern int xonscreen[NUMSPOTS];
extern int yonscreen[NUMSPOTS];

// GAME VARIABLES

extern int  z_car,z_spots,z_min, z_max,
            zspeed, wheeltick, carx,cary,acceltick,
            deceltick, fumeframe, roadx,skytick,skyx;
extern byte lanes,car_dir;
extern signed char wheeloffset;

// GAME FUNCTIONS

extern void gameSetup();
extern void drawSky(int,int);
extern void oneLane();
extern void threeLanes();
#endif
