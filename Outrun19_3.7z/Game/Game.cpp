#include "game.h"
#include "wrapper.h"
#include "sky.h"
#include <iostream>

#define GROUND
#define RUMBLES
#define CURVED

int zlookup[YTABS],x1lookup[YTABS],x2lookup[YTABS],xlookup[YTABS],dxlookup[YTABS];
byte curvature[YTABS];
byte colorlookup[ZLINES*ZSTEP];
int xspots[NUMSPOTS];
int zspots[NUMSPOTS];
int xonscreen[NUMSPOTS];
int yonscreen[NUMSPOTS];

int z_car=200,z_spots=200,z_min=30, z_max=200,
    zspeed = 0, wheeltick=0, carx=TVXCENTER-16,cary=CARY,acceltick=ACCELTIME,
    deceltick=1,fumeframe=0,roadx=0,skytick=0,skyx=0;

byte lanes=3,car_dir=UP;
signed char wheeloffset=0;

//=========================================================================
// Draw sky
//=========================================================================

void drawSky(int x,int y){
     TV.bitmap(x, y, sky);
}

//=========================================================================
// BUILD ROAD GEOMETRY
//=========================================================================

void gameSetup() {
    int k=0;
    // color lookup table
    for (int i=0; i< ZLINES; i++) {
            for (int j=0; j< ZSTEP;j++) colorlookup[i*ZSTEP+j]=(byte)k;
            k = !k;
    }

    // table of spots
    for (int i=0; i < NUMSPOTS; i++) {
        xspots[i] = random(ROADW+50,4000)*Z_MULT;   // distributed round road
        if (random(0,4)<2) xspots[i] *= -1;         // distribute on both sides
        zspots[i] = (z_car)+i*(600/NUMSPOTS);
    }
    k=0;

    // lookup table for z and road sides and curvature
    float c = 0.1;
    for (int y=TVY-1; y>HORIZON ;y--) {
        int zy=HORIZON;
        std::cout << y - HORIZON << std::endl;
        if (y - HORIZON > 0) {zy = Y_CAMERA / (y-HORIZON);
        } else { break;}
        zlookup[k] = zy;
        x1lookup[k] = TVXCENTER - ((ROADW/zy)*Z_MULT);
        x2lookup[k] = TVXCENTER + ((ROADW/zy)*Z_MULT);
        xlookup[k] = (ROADW/zy)*Z_MULT;
        if (TVX > 120) c = c + c * 0.145; else c = c + c * 0.165;
        curvature[k] = c;
        // sideways DX table, is DIVIDED BY DXDIV when calculating !
        dxlookup[k] = (TVXCENTER - x1lookup[k]);
        k++;
    }
}

//=========================================================================
// DRAW 1 LANE
//=========================================================================

void oneLane() {
    // draw ground
    #ifdef GROUND
    for (int screeny=TVY-1; screeny > HORIZON; screeny--) {
        int a,b;
        int q = TVY-screeny; // define index for lookup

        // find road sides
        a = x1lookup[q] + roadx*dxlookup[q]/DXDIV;
        b = x2lookup[q] + roadx*dxlookup[q]/DXDIV;

        // Clean the road
        if (a>=0 && b <=TVX) {
                if (screeny > cary + 14 && screeny < cary + 19 ) {
                    TV.draw_line (a,screeny,carx-14,screeny,0);
                    TV.draw_line (carx+60,screeny,b,screeny,0);
                } else {
                TV.draw_line (a,screeny,b,screeny,0);
                }
        } else {
                TV.draw_line (0,screeny,TVX,screeny,0);
        }

        // check if a or b are out of bounds and draw road sides

        if (a>=0) TV.draw_line (0,screeny,a,screeny,1);
        if (b<=TVX) TV.draw_line (b,screeny,TVX,screeny,1);
    }
    #endif

    //draw spots
    for (int i=0; i < NUMSPOTS; i++) {
        int y,x,z;
        x = xspots[i];
        z = zspots[i];
        // delete the spot
        if (xonscreen[i]>-1) TV.set_pixel (xonscreen[i],yonscreen[i],1);
        // see if spot is out of range
        if (z < z_spots+20) {
            // spot has moved out of sight, push back to horizon
            xspots[i] = random(ROADW+50,4000)*Z_MULT;             // distributed round road
            if (random(0,4)<2) xspots[i] *= -1; // distribute on both sides
            zspots[i] = z_spots+ 600; // push spot to horizon
            x = xspots[i];
            z = zspots[i];
        }
        y = (Y_CAMERA / (z-z_spots)) + HORIZON-2;
        x = x / (z-z_spots) + TVXCENTER +(roadx*dxlookup[TVY-y]/DXDIV);
        if (x>0 && x < TVX) {
                TV.set_pixel (x,y,0);
                xonscreen[i]=x;
                yonscreen[i]=y;
            } else {
                xonscreen[i]=-1; // no need to wipe
            }
        }

    // draw rumbles
    #ifdef RUMBLES
    for (int screeny=TVY-1; screeny > HORIZON; screeny--) {
        int a,b,c,d,dx,zy,rumblew,roffset;
        int q = TVY-screeny;
        zy = zlookup[q];
        if (zy<1) break; // invalid line
        byte col = colorlookup[zy+z_car];
        dx = dxlookup[q]; // find dx width for this Z depth
        rumblew = dx/RUMBLEW;
        roffset = dx/RUMBLEOFFS;
        a = x1lookup[q]+(roadx*dx/DXDIV)+ roffset; // rumble left edge
        b = a+rumblew; // rumble right edge
        if (a<0) a=0; // rumble left edge out of screen check
        if (b>0) TV.draw_line (a,screeny,b,screeny,col); // if rumble is visible, draw
        c = x2lookup[q]+(roadx*dx/DXDIV) - roffset; // right ride of road
        d = c-rumblew; // rumble left edge
        if (c>TVX) c=TVX; // check if roadside is out of screen
        if (d<TVX) TV.draw_line (c,screeny,d,screeny,col); // if visible, draw
    }
    #endif

}

//=========================================================================
// DRAW 3 LANES
//=========================================================================

void threeLanes() {
    // draw ground

    #ifdef GROUND
    for (int screeny=TVY; screeny > HORIZON; screeny--) {
        int a,b;
        int q = TVY-screeny; // define index for lookup
        // find road sides
        #ifdef CURVED
        a = TVXCENTER - xlookup[q]*2 + roadx*dxlookup[q]/DXDIV+curvature[q];
        b = TVXCENTER + xlookup[q]*2 + roadx*dxlookup[q]/DXDIV+curvature[q];
        #else
        a = TVXCENTER - xlookup[q]*2 + roadx*dxlookup[q]/DXDIV;
        b = TVXCENTER + xlookup[q]*2 + roadx*dxlookup[q]/DXDIV;
        #endif
        // Clean the road
        if (a>=0 && b <=TVX) {
                if (screeny > cary + 14 && screeny < cary + 19 ) {
                    TV.draw_line (a,screeny,carx-14,screeny,0);
                    TV.draw_line (carx+60,screeny,b,screeny,0);
                } else {
                TV.draw_line (a,screeny,b,screeny,0);
                }
        } else {
                TV.draw_line (0,screeny,TVX,screeny,0);
        }

        // check if a or b are out of bounds and draw road sides

        if (a>=0) TV.draw_line (0,screeny,a,screeny,1);
        if (b<=TVX) TV.draw_line (b,screeny,TVX,screeny,1);
    }
    #endif

    //draw spots
    for (int i=0; i < NUMSPOTS; i++) {
        int y,x,z;
        x = xspots[i];
        z = zspots[i];
        // delete the spot
        if (xonscreen[i]>-1) TV.set_pixel (xonscreen[i],yonscreen[i],1);
        // see if spot is out of range
        if (z < z_spots+20) {
            // spot has moved out of sight, push back to horizon
            xspots[i] = random(ROADW+50,4000)*Z_MULT*2;      // distributed round road
            if (random(0,4)<2) xspots[i] *= -1; // distribute on both sides
            zspots[i] = z_spots+ 600; // push spot to horizon
            x = xspots[i];
            z = zspots[i];
        }
        y = (Y_CAMERA / (z-z_spots)) + HORIZON;
        x = x / (z-z_spots) + HORIZON+(2*roadx*dxlookup[TVY-y]/DXDIV)+curvature[TVY-y];
        if (x>0 && x < TVX) {
                TV.set_pixel (x,y,0);
                xonscreen[i]=x;
                yonscreen[i]=y;
            } else {
                xonscreen[i]=-1; // no need to wipe
            }
        }

    // draw rumbles
    #ifdef RUMBLES

    for (int screeny=TVY-1; screeny > HORIZON; screeny--) {
        int a,b,c,d,dx,zy,rumblew,roffset,roffset2;
        int q = TVY-screeny;
        zy = zlookup[q];
        if (zy<1) break; // invalid line
        byte col = colorlookup[zy+z_car];
        dx = dxlookup[q]; // find dx width for this Z depth
        rumblew = dx/RUMBLEW;
        //roffset = dx/RUMBLEOFFS;
        roffset = 6*dx/RUMBLEOFFS;
        a = x1lookup[q]+(roadx*dx/DXDIV)+ roffset + curvature[q]; // rumble left edge
        b = a+rumblew; // rumble right edge
        if (a<0) a=0; // rumble left edge out of screen check
        if (b>0) TV.draw_line (a,screeny,b,screeny,col); // if rumble is visible, draw
        c = x2lookup[q]+(roadx*dx/DXDIV) - roffset + curvature[q]; // right ride of road
        d = c-rumblew; // rumble left edge
        if (c>TVX) c=TVX; // check if roadside is out of screen
        if (d<TVX) TV.draw_line (c,screeny,d,screeny,col); // if visible, draw
    }
    #endif
}
