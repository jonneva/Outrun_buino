#ifndef SKY_H
#define SKY_H


extern unsigned char sky[];

#endif

