#include "TVout.h"
#include "wrapper.h"

// Bitmap overlay functions

void overlaybitmap(uint8_t x, uint8_t y, const unsigned char * bmp,
				   uint16_t i, uint8_t width, uint8_t lines) {

	uint8_t temp, lshift, rshift, save, xtra;
	uint16_t si = 0;

	rshift = x&7;
	lshift = 8-rshift;
	if (width == 0) {
	  //width = pgm_read_byte((uint32_t)(bmp) + i);
	  width = bmp[i];
	  i++;
	}
	if (lines == 0) {
	  //lines = pgm_read_byte((uint32_t)(bmp) + i);
	  lines = bmp[i];
	  i++;
	}

	if (width&7) {
	  xtra = width&7;
	  width = width/8;
	  width++;
	}
	else {
	  xtra = 8;
	  width = width/8;
	}

	for (uint8_t l = 0; l < lines; l++) {
	  si = ((y + l) % display.vres)*display.hres + x/8;
	  //si = (y + l)*display.hres + x/8;
	  if (width == 1)
	    temp = 0xff >> rshift + xtra;
	  else
	    temp = 0;
	  save = display.screen[si];
	  //temp = pgm_read_byte((uint32_t)(bmp) + i++);
	  temp = bmp[i++];
	  display.screen[si++] |= temp >> rshift;
	  for ( uint16_t b = i + width-1; i < b; i++) {
	    if (si % display.hres == 0) {
	      // wrapped around to the left side
	      si -= display.hres;
	    }
	    save = display.screen[si];
	    display.screen[si] |= temp << lshift;
	    //temp = pgm_read_byte((uint32_t)(bmp) + i);
	    temp = bmp[i];
	    display.screen[si++] |= temp >> rshift;
	  }
	  if (si % display.hres == 0) {
	    // wrapped around to the left side
	    si -= display.hres;
	  }
	  if (rshift + xtra < 8)
	    display.screen[si-1] |= (save & (0xff >> rshift + xtra));	//test me!!!
	  display.screen[si] |= temp << lshift;
	}
} // end of bitmap

void erasebitmap(uint8_t x, uint8_t y, const unsigned char * bmp,
				   uint16_t i, uint8_t width, uint8_t lines) {

	uint8_t temp, lshift, rshift, save, xtra;
	uint16_t si = 0;

	rshift = x&7;
	lshift = 8-rshift;
	if (width == 0) {
		//width = pgm_read_byte((uint32_t)(bmp) + i);
		width = bmp[i];
		i++;
	}
	if (lines == 0) {
		//lines = pgm_read_byte((uint32_t)(bmp) + i);
		lines = bmp[i];
		i++;
	}

	if (width&7) {
		xtra = width&7;
		width = width/8;
		width++;
	}
	else {
		xtra = 8;
		width = width/8;
	}

	for (uint8_t l = 0; l < lines; l++) {
	  si = ((y + l) % display.vres)*display.hres + x/8;
	  //si = (y + l)*display.hres + x/8;
		if (width == 1)
			temp = 0xff >> rshift + xtra;
		else
			temp = 0;
		save = display.screen[si];
		//temp = pgm_read_byte((uint32_t)(bmp) + i++);
		temp = bmp[i++];
		display.screen[si++] &= ~(temp >> rshift);
		for ( uint16_t b = i + width-1; i < b; i++) {
		  if (si % display.hres == 0) {
		    // wrapped around to the left side
		    si -= display.hres;
		  }
			save = display.screen[si];
			display.screen[si] &= ~(temp << lshift);
			//temp = pgm_read_byte((uint32_t)(bmp) + i);
			temp = bmp[i];
			display.screen[si++] &= ~(temp >> rshift);
		}
		if (si % display.hres == 0) {
		  // wrapped around to the left side
		  si -= display.hres;
		}

		if (rshift + xtra < 8)
			display.screen[si-1] &= ~(save & (0xff >> rshift + xtra));	//test me!!!
		if (rshift + xtra - 8 > 0)
		  display.screen[si] &= ~(temp << lshift);
	}
} // end of bitmap

