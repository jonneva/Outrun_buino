#include "game.h"
#include "wrapper.h"

int zlookup[YTABS],x1lookup[YTABS],x2lookup[YTABS],dxlookup[YTABS];
byte colorlookup[ZLINES*ZSTEP];
int xspots[NUMSPOTS];
int zspots[NUMSPOTS];
int xonscreen[NUMSPOTS];
int yonscreen[NUMSPOTS];

int z_car=200,z_spots=200,z_min=30, z_max=200,
    zspeed = 0, wheeltick=0, carx=viewWidth/2-16,cary=66,acceltick=ACCELTIME,
    deceltick=1,fumeframe=0,roadx=0;

//=========================================================================
// BUILD ROAD GEOMETRY
//=========================================================================

void gameSetup() {
    int k=0;
    // color lookup table
    for (int i=0; i< ZLINES; i++) {
            for (int j=0; j< ZSTEP;j++) colorlookup[i*ZSTEP+j]=(byte)k;
            k = !k;
    }

    // table of spots
    for (int i=0; i < NUMSPOTS; i++) {
        xspots[i] = random(ROADW+50,4000)*Z_MULT;             // distributed round road
        if (random(0,4)<2) xspots[i] *= -1; // distribute on both sides
        zspots[i] = (z_car)+i*(600/NUMSPOTS);
    }
    k=0;

    // lookup table for z and road sides
    for (int y=95; y>viewHeight/2;y--) {
        int zy;
        zy = Y_CAMERA / (y-(viewHeight/2));
        zlookup[k] = zy;
        if (zy < 0) break;
        x1lookup[k] = viewWidth/2 - ((ROADW/zy)*Z_MULT);
        x2lookup[k] = viewWidth/2 + ((ROADW/zy)*Z_MULT);

        // sideways DX table, is DIVIDED BY DXDIV when calculating !
        dxlookup[k] = (viewWidth/2 - x1lookup[k]);
        k++;
    }
}
