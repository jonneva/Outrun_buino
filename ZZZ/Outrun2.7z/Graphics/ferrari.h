#ifndef FERRARI_BITMAP_H
#define FERRARI_LOGO_BITMAP_H


extern unsigned char ferrari_bitmap[];
extern unsigned char wheels1[];
extern unsigned char wheels2[];
extern unsigned char wheels3[];
extern unsigned char fumes1[];
extern unsigned char fumes2[];
extern unsigned char fumes3[];

#endif

