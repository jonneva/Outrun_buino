// SFML_TVout ... port of TVout library to SFML / Jonne Valola

#include <SFML/Graphics.hpp>
#include <iostream>
#include <math.h>
#include "wrapper.h"
#include "TVout.h"
#include "fontALL.h"
#include "game.h"
#include "ferrari.h"

using namespace std;
using namespace sf;

// START OF ARDUINO CODE
int skyy = 11;
#define SKY

#include <Controllers.h>

void setup() {
    TV.begin(_PAL, viewWidth, viewHeight);
    TV.select_font(font8x8);
    gameSetup();
    #ifdef SKY
        drawSky(skyx,skyy);
    #endif // SKY
}

void loop() {
    int xtemp,zlook;

    TV.delay_frame(10);
    if (skytick > 1){
        //TV.shift(zspeed/100,LEFT);
        skyx--;
        if (skyx < 0) { skyx=viewWidth-1; skyy--;}
        skytick =0;
        drawSky(skyx,skyy);
    }
    TV.draw_line(0,49,viewWidth,49,1);
    TV.print(viewWidth/2+25,6,"     ");
    //TV.print(0,2,skyx);
    if (zspeed < 10) TV.print(viewWidth/2+25+3*8,6,zspeed);
    else if (zspeed < 100) TV.print(viewWidth/2+25+2*8,6,zspeed);
    if (zspeed > 100) TV.print(viewWidth/2+25+1*8,6,zspeed);
    threeLanes();

    // draw car
    overlaybitmap(carx,cary, ferrari_bitmap, 0, 0, 0);
    if (Controller.upPressed()) {
            if (acceltick>0) {
                if (fumeframe == 0) TV.bitmap(carx-14,cary+14,fumes1);
                if (fumeframe == 3) TV.bitmap(carx-14,cary+14,fumes2);
                if (fumeframe == 9) TV.bitmap(carx-14,cary+14,fumes3);
                fumeframe++;
                if (fumeframe == 12) fumeframe=0;
                acceltick--;
                if (acceltick == 0) {
                    //TV.draw_rect(carx-14,cary+14,carx+46,cary+19,0,0);
                    //overlaybitmap(carx,cary, ferrari_bitmap, 0, 0, 0);
                }
            }
            zspeed+=10;
    } else {
        if (deceltick) zspeed-=4;
        deceltick = !deceltick;
        if (acceltick != 30 ) {
        acceltick = ACCELTIME;
        fumeframe=0;
        //TV.draw_rect(carx-14,cary+14,carx+46,cary+19,0,0);
        //overlaybitmap(carx,cary, ferrari_bitmap, 0, 0, 0);
        }
    }
    if (Controller.downPressed()) zspeed-=15;
    if (zspeed<0) zspeed = 0;
    if (zspeed>293) zspeed = 293;
    if (Controller.leftPressed()) {
            roadx+=(1+zspeed/100);
            }
    if (Controller.rightPressed()) {
            roadx-=(1+zspeed/100);
    }
    z_car += zspeed/10 ;
    z_spots += zspeed/5 ;
    skytick+= zspeed/100;
    if (z_car>800) {
            z_car=200;
    }
    if (zspeed>10) {
            if (wheeltick == 0) TV.bitmap(carx, cary+17, wheels1);
            if (wheeltick == 1) TV.bitmap(carx, cary+17, wheels2);
            if (wheeltick == 2) {
                    TV.bitmap(carx, cary+17, wheels3);
                    wheeltick = 0;
            } else { wheeltick++; }
    }
}


// END OF ARDUINO CODE

int main()
{
    std::cout << "SFML TVout emulator started" << std::endl;
	TVsetup();
    setup();

while (window.isOpen())
    {
	loop();
    }
	return 0;
}

