#include "game.h"
#include "wrapper.h"
#include "sky.h"

#define GROUND
#define RUMBLES

int zlookup[YTABS],x1lookup[YTABS],x2lookup[YTABS],xlookup[YTABS],dxlookup[YTABS];
byte curvature[YTABS];
byte colorlookup[ZLINES*ZSTEP];
int xspots[NUMSPOTS];
int zspots[NUMSPOTS];
int xonscreen[NUMSPOTS];
int yonscreen[NUMSPOTS];

int z_car=200,z_spots=200,z_min=30, z_max=200,
    zspeed = 0, wheeltick=0, carx=viewWidth/2-16,cary=66,acceltick=ACCELTIME,
    deceltick=1,fumeframe=0,roadx=0,skytick=0,skyx=0;

byte lanes=3;

//=========================================================================
// Draw sky
//=========================================================================

void drawSky(int x,int y){
     TV.bitmap(x, y, sky);
}

//=========================================================================
// BUILD ROAD GEOMETRY
//=========================================================================

void gameSetup() {
    int k=0;
    // color lookup table
    for (int i=0; i< ZLINES; i++) {
            for (int j=0; j< ZSTEP;j++) colorlookup[i*ZSTEP+j]=(byte)k;
            k = !k;
    }

    // table of spots
    for (int i=0; i < NUMSPOTS; i++) {
        xspots[i] = random(ROADW+50,4000)*Z_MULT;             // distributed round road
        if (random(0,4)<2) xspots[i] *= -1; // distribute on both sides
        zspots[i] = (z_car)+i*(600/NUMSPOTS);
    }
    k=0;

    // lookup table for z and road sides and curvature
    float c = 0.1;
    for (int y=95; y>viewHeight/2;y--) {
        int zy;
        zy = Y_CAMERA / (y-(viewHeight/2));
        zlookup[k] = zy;
        if (zy < 0) break;
        x1lookup[k] = viewWidth/2 - ((ROADW/zy)*Z_MULT);
        x2lookup[k] = viewWidth/2 + ((ROADW/zy)*Z_MULT);
        xlookup[k] = (ROADW/zy)*Z_MULT;
        c = c + c * 0.145;
        curvature[k] = c;
        // sideways DX table, is DIVIDED BY DXDIV when calculating !
        dxlookup[k] = (viewWidth/2 - x1lookup[k]);
        k++;
    }
}

//=========================================================================
// DRAW 1 LANE
//=========================================================================

void oneLane() {
    // draw ground
    #ifdef GROUND
    for (int screeny=95; screeny > 49; screeny--) {
        int a,b;
        int q = viewHeight-screeny; // define index for lookup

        // find road sides
        a = x1lookup[q] + roadx*dxlookup[q]/DXDIV;
        b = x2lookup[q] + roadx*dxlookup[q]/DXDIV;

        // Clean the road
        if (a>=0 && b <=viewWidth) {
                if (screeny > cary + 14 && screeny < cary + 19 ) {
                    TV.draw_line (a,screeny,carx-14,screeny,0);
                    TV.draw_line (carx+60,screeny,b,screeny,0);
                } else {
                TV.draw_line (a,screeny,b,screeny,0);
                }
        } else {
                TV.draw_line (0,screeny,viewWidth,screeny,0);
        }

        // check if a or b are out of bounds and draw road sides

        if (a>=0) TV.draw_line (0,screeny,a,screeny,1);
        if (b<=viewWidth) TV.draw_line (b,screeny,viewWidth,screeny,1);
    }
    #endif

    //draw spots
    for (int i=0; i < NUMSPOTS; i++) {
        int y,x,z;
        x = xspots[i];
        z = zspots[i];
        // delete the spot
        if (xonscreen[i]>-1) TV.set_pixel (xonscreen[i],yonscreen[i],1);
        // see if spot is out of range
        if (z < z_spots+20) {
            // spot has moved out of sight, push back to horizon
            xspots[i] = random(ROADW+50,4000)*Z_MULT;             // distributed round road
            if (random(0,4)<2) xspots[i] *= -1; // distribute on both sides
            zspots[i] = z_spots+ 600; // push spot to horizon
            x = xspots[i];
            z = zspots[i];
        }
        y = (Y_CAMERA / (z-z_spots)) + (viewHeight/2);
        x = x / (z-z_spots) + (viewWidth/2)+(roadx*dxlookup[viewHeight-y]/DXDIV);
        if (x>0 && x < viewWidth) {
                TV.set_pixel (x,y,0);
                xonscreen[i]=x;
                yonscreen[i]=y;
            } else {
                xonscreen[i]=-1; // no need to wipe
            }
        }

    // draw rumbles
    #ifdef RUMBLES
    for (int screeny=94; screeny > viewHeight/2; screeny--) {
        int a,b,c,d,dx,zy,rumblew,roffset;
        int q = viewHeight-screeny;
        zy = zlookup[q];
        if (zy<1) break; // invalid line
        byte col = colorlookup[zy+z_car];
        dx = dxlookup[q]; // find dx width for this Z depth
        rumblew = dx/RUMBLEW;
        roffset = dx/RUMBLEOFFS;
        a = x1lookup[q]+(roadx*dx/DXDIV)+ roffset; // rumble left edge
        b = a+rumblew; // rumble right edge
        if (a<0) a=0; // rumble left edge out of screen check
        if (b>0) TV.draw_line (a,screeny,b,screeny,col); // if rumble is visible, draw
        c = x2lookup[q]+(roadx*dx/DXDIV) - roffset; // right ride of road
        d = c-rumblew; // rumble left edge
        if (c>viewWidth) c=viewWidth; // check if roadside is out of screen
        if (d<viewWidth) TV.draw_line (c,screeny,d,screeny,col); // if visible, draw
    }
    #endif

}

//=========================================================================
// DRAW 3 LANES
//=========================================================================

void threeLanes() {
    // draw ground

    #ifdef GROUND
    for (int screeny=95; screeny > 49; screeny--) {
        int a,b;
        int q = viewHeight-screeny; // define index for lookup
        // find road sides
        a = viewWidth/2 - xlookup[q]*2 + roadx*dxlookup[q]/DXDIV+curvature[q];
        b = viewWidth/2 + xlookup[q]*2 + roadx*dxlookup[q]/DXDIV+curvature[q];

        // Clean the road
        if (a>=0 && b <=viewWidth) {
                if (screeny > cary + 14 && screeny < cary + 19 ) {
                    TV.draw_line (a,screeny,carx-14,screeny,0);
                    TV.draw_line (carx+60,screeny,b,screeny,0);
                } else {
                TV.draw_line (a,screeny,b,screeny,0);
                }
        } else {
                TV.draw_line (0,screeny,viewWidth,screeny,0);
        }

        // check if a or b are out of bounds and draw road sides

        if (a>=0) TV.draw_line (0,screeny,a,screeny,1);
        if (b<=viewWidth) TV.draw_line (b,screeny,viewWidth,screeny,1);
    }
    #endif

    //draw spots
    for (int i=0; i < NUMSPOTS; i++) {
        int y,x,z;
        x = xspots[i];
        z = zspots[i];
        // delete the spot
        if (xonscreen[i]>-1) TV.set_pixel (xonscreen[i],yonscreen[i],1);
        // see if spot is out of range
        if (z < z_spots+20) {
            // spot has moved out of sight, push back to horizon
            xspots[i] = random(ROADW+50,4000)*Z_MULT*2;      // distributed round road
            if (random(0,4)<2) xspots[i] *= -1; // distribute on both sides
            zspots[i] = z_spots+ 600; // push spot to horizon
            x = xspots[i];
            z = zspots[i];
        }
        y = (Y_CAMERA / (z-z_spots)) + (viewHeight/2);
        x = x / (z-z_spots) + (viewWidth/2)+(2*roadx*dxlookup[viewHeight-y]/DXDIV)+curvature[viewHeight-y];
        if (x>0 && x < viewWidth) {
                TV.set_pixel (x,y,0);
                xonscreen[i]=x;
                yonscreen[i]=y;
            } else {
                xonscreen[i]=-1; // no need to wipe
            }
        }

    // draw rumbles
    #ifdef RUMBLES

    for (int screeny=94; screeny > viewHeight/2; screeny--) {
        int a,b,c,d,dx,zy,rumblew,roffset,roffset2;
        int q = viewHeight-screeny;
        zy = zlookup[q];
        if (zy<1) break; // invalid line
        byte col = colorlookup[zy+z_car];
        dx = dxlookup[q]; // find dx width for this Z depth
        rumblew = dx/RUMBLEW;
        //roffset = dx/RUMBLEOFFS;
        roffset = 6*dx/RUMBLEOFFS;
        a = x1lookup[q]+(roadx*dx/DXDIV)+ roffset + curvature[q]; // rumble left edge
        b = a+rumblew; // rumble right edge
        if (a<0) a=0; // rumble left edge out of screen check
        if (b>0) TV.draw_line (a,screeny,b,screeny,col); // if rumble is visible, draw
        c = x2lookup[q]+(roadx*dx/DXDIV) - roffset + curvature[q]; // right ride of road
        d = c-rumblew; // rumble left edge
        if (c>viewWidth) c=viewWidth; // check if roadside is out of screen
        if (d<viewWidth) TV.draw_line (c,screeny,d,screeny,col); // if visible, draw
    }
    #endif
}
